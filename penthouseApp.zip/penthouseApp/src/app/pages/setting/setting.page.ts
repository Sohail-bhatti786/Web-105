import { Component, OnInit, Renderer2 } from '@angular/core';
import { UiService } from 'src/app/services/ul/ui.service';


@Component({
  selector: 'app-setting',
  templateUrl: './setting.page.html',
  styleUrls: ['./setting.page.scss'],
})
export class SettingPage implements OnInit {

  constructor(private renderer:Renderer2,private uiServices:UiService) { }

  ngOnInit() {
  }

  

  onToggleColorTheme(event){
    console.log(event.detail.checked);
    if(event.detail.checked){
      
        this.uiServices.enableDarkTheme(true);
      
    }
    else{
      this.uiServices.enableDarkTheme(false);
    }
  }
}   
