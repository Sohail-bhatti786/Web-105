export const firebaseConfig = {
    apiKey: "AIzaSyDIv5hVr9hWNYjshS8uxgufE2VbGNr8uKU",
    authDomain: "penthouse-47b7e.firebaseapp.com",
    projectId: "penthouse-47b7e",
    storageBucket: "penthouse-47b7e.appspot.com",
    messagingSenderId: "540953584686",
    appId: "1:540953584686:web:3a07372ac568ccb29eabbf"
  };