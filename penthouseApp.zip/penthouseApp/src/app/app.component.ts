import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
import { UiService } from './services/ul/ui.service';
import * as firebase from 'firebase/app';
import { firebaseConfig } from './firebaseConfig';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(private uiservices:UiService, private plt:Platform) { this.initApp(); }

  initApp(){
    this.plt.ready().then(_ => {
      this.uiservices.watchTheme();
    });
    firebase.initializeApp(firebaseConfig);
  }
}
