import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UiService {

  constructor() { }

  watchTheme(){
    let prefersDark = window.matchMedia('(prefers-color-scheme:dark)');
    this.enableDarkTheme(prefersDark.matches);

    prefersDark.addEventListener('change',(media) => {
      this.enableDarkTheme(media.matches);
    })
  }

  enableDarkTheme(enable:boolean){
    document.body.classList.toggle('dark',enable);
  }
}
